package com.mercado.inteligente.controller;



import com.mercado.inteligente.command.CriarDeliveryCommand;
import com.mercado.inteligente.command.ExcluirProdutoCommand;
import com.mercado.inteligente.command.NovoProdutoCommand;
import com.mercado.inteligente.dao.*;
import com.mercado.inteligente.model.*;
import com.mercado.inteligente.view.MercadoInteligenteGUI;
import java.util.List;
import javax.swing.JOptionPane;
 
    private void carregarProdutos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
public class MercadoController {
 
    private final MercadoInteligenteGUI view;
    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private final DeliveryDAO deliveryDAO = new DeliveryDAO();
 
    public MercadoController(MercadoInteligenteGUI view) {
        this.view = view;
    }
 
    // ===================== PRODUTOS =====================
   public void carregarProdutos() {

view.atualizarTabelaProdutos(produtoDAO.listarTodos());

}



public void novoProduto() {

new NovoProdutoCommand(produtoDAO).execute();

carregarProdutos();

}
 
    public void atualizarEstoque() {
        try {
            Long id = Long.parseLong(JOptionPane.showInputDialog("ID do produto:"));
            int novoEstoque = Integer.parseInt(JOptionPane.showInputDialog("Nova quantidade em estoque:"));
 
            Produto p = produtoDAO.buscarPorId(id);
            if (p != null) {
                p.setQuantidadeEstoque(novoEstoque);
                produtoDAO.atualizar(p);
                carregarProdutos();
                JOptionPane.showMessageDialog(null, "Estoque atualizado!");
            } else {
                JOptionPane.showMessageDialog(null, "Produto não encontrado!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar estoque.");
        }
    }
 
   public void excluirProduto() {

new ExcluirProdutoCommand(produtoDAO, view).execute();

carregarProdutos();

}
 
  
    public void verDetalhesProduto() {
        try {
            // Janela pedindo o ID do produto
            String input = JOptionPane.showInputDialog(null,
                "Digite o ID do produto:",
                "Ver Detalhes do Produto",
                JOptionPane.QUESTION_MESSAGE);
 
            if (input == null || input.trim().isEmpty()) {
                return; // Usuário cancelou ou não digitou nada
            }
 
            Long idProduto = Long.parseLong(input.trim());
 
            Produto produto = produtoDAO.buscarPorId(idProduto);
 
            if (produto != null) {
                String detalhes = "=== DETALHES DO PRODUTO ===\n\n" +
                                 "ID: " + produto.getId() + "\n" +
                                 "Código de Barras: " + produto.getCodigoBarras() + "\n" +
                                 "Nome: " + produto.getNome() + "\n" +
                                 "Preço: R$ " + String.format("%.2f", produto.getPreco()) + "\n" +
                                 "Estoque Atual: " + produto.getQuantidadeEstoque() + " unidades";
 
                JOptionPane.showMessageDialog(null, detalhes,
                    "Detalhes do Produto - ID " + idProduto,
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null,
                    "Produto com ID " + idProduto + " não encontrado!",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                "Por favor, digite um número válido para o ID!",
                "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Erro ao buscar detalhes: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}

public void criarDelivery() {

new CriarDeliveryCommand(deliveryDAO, produtoDAO).execute();

carregarProdutos();

}



public void listarDeliveries() {

new ListarDeliveriesCommand(deliveryDAO, view).execute();

}



public void excluirDelivery() {

new ExcluirDeliveryCommand(deliveryDAO, view).execute();

listarDeliveries();

}

