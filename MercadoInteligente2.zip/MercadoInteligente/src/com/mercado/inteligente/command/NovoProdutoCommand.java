/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mercado.inteligente.command;


import com.mercado.inteligente.dao.ProdutoDAO;

import com.mercado.inteligente.model.Produto;

import javax.swing.JOptionPane;


public class NovoProdutoCommand implements Command {

private final ProdutoDAO produtoDAO;


public NovoProdutoCommand(ProdutoDAO produtoDAO) {
this.produtoDAO = produtoDAO;

};


public void execute(Produto p) {

try {

String codigo = JOptionPane.showInputDialog("Código de barras:");

String nome = JOptionPane.showInputDialog("Nome do produto:");

double preco = Double.parseDouble(JOptionPane.showInputDialog("Preço:"));

int estoque = Integer.parseInt(JOptionPane.showInputDialog("Estoque inicial:"));

produtoDAO.salvar(p);

JOptionPane.showMessageDialog(null, "Produto salvo com sucesso!");

} catch (Exception e) {

JOptionPane.showMessageDialog(null, "Erro ao criar produto.");

}

}

    @Override
    public void execute() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}