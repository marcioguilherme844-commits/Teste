package com.mercado.inteligentecontroller;
 
import com.mercado.inteligente.dao.*;
import com.mercado.inteligente.model.*;
import com.mercado.inteligente.view.MercadoInteligenteGUI;
import java.util.List;
import javax.swing.JOptionPane;
 
public class MercadoController {
 
    private final MercadoInteligenteGUI view;
    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private final DeliveryDAO deliveryDAO = new DeliveryDAO();
 
    public MercadoController(MercadoInteligenteGUI view) {
        this.view = view;
    }
 
    // ===================== PRODUTOS =====================
    public void carregarProdutos() {
        List<Produto> produtos = produtoDAO.listarTodos();
        view.atualizarTabelaProdutos(produtos);
    }
 
    public void novoProduto() {
        try {
            String codigo = JOptionPane.showInputDialog("Código de barras:");
            String nome = JOptionPane.showInputDialog("Nome do produto:");
            double preco = Double.parseDouble(JOptionPane.showInputDialog("Preço:"));
            int estoque = Integer.parseInt(JOptionPane.showInputDialog("Estoque inicial:"));
 
            Produto p = new Produto(null, codigo, nome, preco, estoque);
            produtoDAO.salvar(p);
            carregarProdutos();
            JOptionPane.showMessageDialog(null, "Produto salvo com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar produto: " + e.getMessage());
        }
    }
 
    public void atualizarEstoque() {
        try {
            Long id = Long.parseLong(JOptionPane.showInputDialog("ID do produto:"));
            int novoEstoque = Integer.parseInt(JOptionPane.showInputDialog("Nova quantidade em estoque:"));
 
            Produto p = produtoDAO.buscarPorId(id);
            if (p != null) {
                p.setQuantidadeEstoque(novoEstoque);
                produtoDAO.atualizar(p);
                carregarProdutos();
                JOptionPane.showMessageDialog(null, "Estoque atualizado!");
            } else {
                JOptionPane.showMessageDialog(null, "Produto não encontrado!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar estoque.");
        }
    }
 
    public void excluirProduto() {
        try {
            int linha = view.getTabelaProdutos().getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(null, "Selecione um produto para excluir!");
                return;
            }
 
            Long id = (Long) view.getTabelaProdutos().getValueAt(linha, 0);
            int confirm = JOptionPane.showConfirmDialog(null, "Excluir este produto?", "Confirmar", JOptionPane.YES_NO_OPTION);
 
            if (confirm == JOptionPane.YES_OPTION) {
                produtoDAO.deletar(id);
                carregarProdutos();
                JOptionPane.showMessageDialog(null, "Produto excluído!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir produto.");
        }
    }
 
    public void criarDelivery() {
        try {
            // 1. Pede o ID do Produto
            String idStr = JOptionPane.showInputDialog(null, 
                "Digite o ID do Produto:", 
                "Criar Delivery", JOptionPane.QUESTION_MESSAGE);
 
            if (idStr == null || idStr.trim().isEmpty()) return;
 
            Long produtoId = Long.parseLong(idStr.trim());
 
            // 2. Busca o produto e verifica estoque
            Produto produto = produtoDAO.buscarPorId(produtoId);
            if (produto == null) {
                JOptionPane.showMessageDialog(null, "Produto não encontrado!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
 
            if (produto.getQuantidadeEstoque() <= 0) {
                JOptionPane.showMessageDialog(null, 
                    "Não tem estoque suficiente para este produto!\nEstoque atual: " + produto.getQuantidadeEstoque(), 
                    "Estoque Insuficiente", JOptionPane.ERROR_MESSAGE);
                return;
            }
 
            // 3. Pede o endereço de entrega
            String endereco = JOptionPane.showInputDialog(null, 
                "Digite o endereço completo de entrega:", 
                "Endereço de Entrega", JOptionPane.QUESTION_MESSAGE);
 
            if (endereco == null || endereco.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Endereço é obrigatório!");
                return;
            }
 
            // 4. Pede a taxa de entrega
            String taxaStr = JOptionPane.showInputDialog(null, 
                "Taxa de entrega (padrão R$ 8,90):", 
                "Taxa de Entrega", JOptionPane.QUESTION_MESSAGE);
 
            double taxa = 8.90;
            if (taxaStr != null && !taxaStr.trim().isEmpty()) {
                try {
                    taxa = Double.parseDouble(taxaStr.trim());
                } catch (NumberFormatException ex) {
                    taxa = 8.90;
                }
            }
 
            // 5. Cria o Delivery
            Delivery delivery = new Delivery.DeliveryBuilder()
                    .enderecoEntrega(endereco.trim())
                    .taxaEntrega(taxa)
                    .build();
 
            // 6. Salva o Delivery
            deliveryDAO.salvar(delivery);
 
            // 7. Reduz o estoque do produto (1 unidade, já que é um delivery)
            produto.reduzirEstoque(1);
            produtoDAO.atualizar(produto);
 
            // Mensagem de sucesso
            JOptionPane.showMessageDialog(null, 
                "✅ Delivery criado com sucesso!\n\n" +
                "ID Delivery: " + delivery.getId() + "\n" +
                "Produto: " + produto.getNome() + " (ID: " + produto.getId() + ")\n" +
                "Endereço: " + endereco.trim() + "\n" +
                "Taxa: R$ " + String.format("%.2f", taxa), 
                "Sucesso", JOptionPane.INFORMATION_MESSAGE);
 
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido. Digite apenas números.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Erro de Estoque", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao criar Delivery: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    public void excluirDelivery() {
        try {
            String inputId = JOptionPane.showInputDialog(null, 
                "Digite o ID do Delivery que deseja excluir:", 
                "Excluir Delivery", JOptionPane.QUESTION_MESSAGE);
 
            if (inputId == null || inputId.trim().isEmpty()) {
                return;
            }
 
            Long deliveryId = Long.parseLong(inputId.trim());
 
            int confirmacao = JOptionPane.showConfirmDialog(null, 
                "Tem certeza que deseja excluir o Delivery ID " + deliveryId + "?", 
                "Confirmar Exclusão", 
                JOptionPane.YES_NO_OPTION);
 
            if (confirmacao == JOptionPane.YES_OPTION) {
                deliveryDAO.deletar(deliveryId);
                JOptionPane.showMessageDialog(null, "Delivery excluído com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido. Digite apenas números.", "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir Delivery: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    public void listarTodosDeliveries() {
        try {
            List<Delivery> deliveries = deliveryDAO.listarTodos();
            view.atualizarTabelaDeliveries(deliveries);
            
            if (deliveries.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nenhum Delivery encontrado.", "Informação", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Deliveries: " + e.getMessage());
        }
    }
    
  
    public void verDetalhesProduto() {
        try {
            // Janela pedindo o ID do produto
            String input = JOptionPane.showInputDialog(null,
                "Digite o ID do produto:",
                "Ver Detalhes do Produto",
                JOptionPane.QUESTION_MESSAGE);
 
            if (input == null || input.trim().isEmpty()) {
                return; // Usuário cancelou ou não digitou nada
            }
 
            Long idProduto = Long.parseLong(input.trim());
 
            Produto produto = produtoDAO.buscarPorId(idProduto);
 
            if (produto != null) {
                String detalhes = "=== DETALHES DO PRODUTO ===\n\n" +
                                 "ID: " + produto.getId() + "\n" +
                                 "Código de Barras: " + produto.getCodigoBarras() + "\n" +
                                 "Nome: " + produto.getNome() + "\n" +
                                 "Preço: R$ " + String.format("%.2f", produto.getPreco()) + "\n" +
                                 "Estoque Atual: " + produto.getQuantidadeEstoque() + " unidades";
 
                JOptionPane.showMessageDialog(null, detalhes,
                    "Detalhes do Produto - ID " + idProduto,
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null,
                    "Produto com ID " + idProduto + " não encontrado!",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                "Por favor, digite um número válido para o ID!",
                "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Erro ao buscar detalhes: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}